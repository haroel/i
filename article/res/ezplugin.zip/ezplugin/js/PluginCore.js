/**
 *
 * java反射插件模块
 * 核心类,请不要修改内部对象属性和方法
 *
 * Author      : hhe
 * Create Time :2017/7/17
 */
let Hash = require("Hash");

let PluginCorePATH = "";

let CallBACK_ID_GENERATOR = (function () {
    let i = 1;
    return function () {
        return i++;
    }
})();

let javaToJSeventHashs = new Hash();
let javaToJScallbackHashs = new Hash();

let __getCallbackId = function (callback) {
    if (typeof callback === 'function'){
        let cid = CallBACK_ID_GENERATOR();
        javaToJScallbackHashs.add(cid,callback);
        return cid;
    }
    return 0;
};
/**
 * PluginCore支持的操作环境
 */
let isSysSupport = function(){
    return cc.sys.os === cc.sys.OS_ANDROID || cc.sys.os === cc.sys.OS_IOS;
}

let PluginCore = {};
PluginCore.initAllPlugins = function (PluginConfig, corePath, callback ) {
    cc.log("PluginCore->initAllPlugins");    
    try{
        let _callId = __getCallbackId(callback);
        if ( isSysSupport() ){
            PluginCorePATH = corePath;
            let params = JSON.stringify(PluginConfig);
            if (cc.sys.OS_ANDROID === cc.sys.os) {
                jsb.reflection.callStaticMethod(PluginCorePATH,
                    "initAllPlugins",
                    "(Ljava/lang/String;I)V", params,_callId );
            }else if (cc.sys.OS_IOS === cc.sys.os) {
                jsb.reflection.callStaticMethod(PluginCorePATH,
                    "initAllPlugins:andCallback:",
                    params,_callId);
            }
            return true;            
        }else{
            if (callback){
                callback("1");
            }
            cc.log("PluginCore",`[注意] 当前系统无法进行插件初始化！`);
        }
    }catch (e) {
        cc.log("PluginCore->initAllPlugins 错误",e);
    }
    return false;    
};
/*
 * 初始化某一个插件，参数必须是类似如下形式的对象
    {
        pluginName : "XXX",
        params     : {
            appId:"xxxx"
        }
    }
 * */
PluginCore.initPlugin = function ( pluginData ) {
    try{
        if ( isSysSupport() && PluginCorePATH ){
            let params = JSON.stringify( pluginData["params"] );
            if (cc.sys.OS_ANDROID === cc.sys.os) {
                jsb.reflection.callStaticMethod(PluginCorePATH,
                    "initPlugin",
                    "(Ljava/lang/String;Ljava/lang/String;)V", pluginData["pluginName"],params );
            }else if (cc.sys.OS_IOS === cc.sys.os) {
                jsb.reflection.callStaticMethod(PluginCorePATH,
                    "initPlugin:andPluginData:",
                    pluginData["pluginName"],params);
            }
            return true;            
        }else{
            cc.log("PluginCore",`[注意] 当前系统无法进行${pluginData["pluginName"]}插件初始化！`);
        }
    }catch (e) {
        cc.log("PluginCore->initPlugin 错误",e);
    }
    return false;    
};

PluginCore.excute = function (pluginName, action ,params,callback,reflectFuncOrNull) {
    try{
        if ( isSysSupport() ){
            let _params = "";
            if (!params) {
                _params = "";
            } else if (typeof params === "object") {
                _params = JSON.stringify(params);
            }else{
                _params = params+"";
            }
            let callId = __getCallbackId(callback);
            if (cc.sys.OS_ANDROID === cc.sys.os) {
                let callName = reflectFuncOrNull || 'excutePluginAction';
                jsb.reflection.callStaticMethod(PluginCorePATH,
                    callName,
                    "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V",
                    pluginName, action , _params, callId );
            }else if (cc.sys.OS_IOS === cc.sys.os) {
                jsb.reflection.callStaticMethod(PluginCorePATH,
                    'excutePluginAction:andAction:andParams:andCallBack:',
                    pluginName, action, _params, callId );
            }else{
                cc.log("PluginCore",`[注意] 系统不支持该调用, ${pluginName}, ${action}`);
            }
            return callId;
        }else{
            cc.log("PluginCore",`[注意] 当前系统不支持该调用, ${pluginName}, ${action}`);
        }
    }catch (e) {
        cc.log("PluginCore->excute 错误",e);
    }
    return 0;    
};

PluginCore.excuteInUITheard = function (pluginName, action ,params,callback) {
    if (cc.sys.OS_ANDROID === cc.sys.os) {
        return PluginCore.excute(pluginName,action,params,callback,'excutePluginActionInUITheard');
    }
    if (cc.sys.OS_IOS === cc.sys.os) {
        return PluginCore.excute(pluginName,action,params,callback);
    }
    return 0;
};

/*
 * 注册插件事件
 * 返回一个事件ID
 * */
PluginCore.addEventListener = function (pluginName, callback ) {
    if ( isSysSupport() ){
        let obj = {};
        obj["pluginName"] = pluginName;
        obj["callback"] = callback;
        let cid = CallBACK_ID_GENERATOR();
        javaToJSeventHashs.add(cid,obj);
        return cid;        
    }
    return 0;
};

/*
 * 删除插件事件
 * callbackIdOrPluginName: evtId 或者插件名
 * */
PluginCore.removeEventListener = function ( eventIdOrPluginName ) {
    if ( isSysSupport() ){
        if ( typeof eventIdOrPluginName === "number"){
            javaToJSeventHashs.remove(eventIdOrPluginName);
        }if ( typeof eventIdOrPluginName === "string"){
            javaToJSeventHashs.forEach(function (obj, key ) {
                if (obj["pluginName"] === eventIdOrPluginName){
                    javaToJSeventHashs.remove(key)
                }
            })
        }
    }
};

/*
* 清理事件回调数据
* */
PluginCore.dispose = function () {
    cc.log("清空PluginCore.js模块回调数据");
    javaToJScallbackHashs.clear();
    javaToJSeventHashs.clear();
};

// 由java或oc 回调此方法, 请不要再JS层调用!
PluginCore.nativeCallbackHandler = function ( pluginName, event, params ) {
    javaToJSeventHashs.forEach(function ( obj, cid ) {
        if (obj["pluginName"] === pluginName){
            obj["callback"](event,params);
        }
    })
};
// 由java或oc 回调此方法, 请不要再JS层调用!
PluginCore.nativeCallbackHandlerOnce = function ( callbackId, params ) {
    let callback = javaToJScallbackHashs.get(callbackId);
    if (callback){
        callback(params);
        // 未防止内存泄漏,一旦回调完成,callback的引用将会被去掉!!!!
        javaToJScallbackHashs.remove(callbackId)
    }else{
        cc.log("[PluginCore] nativeCallbackHandlerOnce error, callbackId not found!", callbackId )
        cc.log("Callback ids:", JSON.stringify(javaToJScallbackHashs.keys()) );                
    }
};
module.exports = PluginCore;
