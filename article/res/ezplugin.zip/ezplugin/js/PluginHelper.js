/**
 * 封装PluginCore方法,
 * Author      : hhe
 * Create Time :2017/7/20
 */
const PluginCoreJAVAPATH = "com/sdkplugin/core/PluginCore";
const PluginsConfig_android = [
    {
        pluginName :"PluginBugly",                                          
        params     : {"appId":"7dc149a264", "debug": false}
    },
    {
        pluginName : "PluginWechat",
        params     : {
            appId:"wxda7e4597f50da03b",
            appSecret:"135291c11cd4230074f2979c31cb957d"
        }
    },
    {
        pluginName :"PluginMWindow",                                         
        params     : {"debug": true}
    }
];
const PluginCoreIOSPATH = "PluginCore";
const PluginsConfig_IOS = [
    {
        pluginName :"PluginBugly",                                          
        params     : {"appId":"9ec41bed4e", "debug": false}
    },
    {
        pluginName : "PluginWechat",
        params     : {
            appId:"wxda7e4597f50da03b",
            appSecret:"135291c11cd4230074f2979c31cb957d"
        }
    },
    {
        pluginName :"PluginMWindow",                                          
        params     : {
            "appKey":"LXCIBXQ4W1HQPE2W9K1CXM000U3OR7DH",
            "mlinkKey":"tarkgame_80qp",
            "scheme":"tarkgame" // ios scheme过滤
        }
    }
];

const PluginCore = require("PluginCore");
let PluginHelper = {};
PluginHelper.init = function () {
    let plugins = null;
    let pluginCorePATH = "";
    if (cc.sys.OS_ANDROID === cc.sys.os) {
        plugins = PluginsConfig_android;
        pluginCorePATH = PluginCoreJAVAPATH;
    }else if (cc.sys.OS_IOS === cc.sys.os) {
        plugins = PluginsConfig_IOS;
        pluginCorePATH = PluginCoreIOSPATH;
    }else if ( cc.sys.isBrowser ) {
    }
    if (!plugins){
        // 以下代码为了让pluginhelper兼容浏览器和模拟器调用不报错
        plugins = PluginsConfig_android;
    }
    // 把PluginCore的方法反射到PluginHelper对象上
    plugins.forEach(function ( pluginData ) {
        let pName = pluginData["pluginName"];
        let M = {};
        M._$params = pluginData["params"];
        M.excute = function ( action ,params,callback ) {
            return PluginCore.excute(pName,action , params, callback )
        };
        M.excuteInUITheard = function ( action , params, callback ) {
            return PluginCore.excuteInUITheard(pName,action , params, callback )
        };
        M.addEventListener = function (callback) {
            return PluginCore.addEventListener(pName,callback);
        };
        M.removeEventListener = function ( eventIdOrPluginName ) {
            if (!eventIdOrPluginName){
                PluginCore.removeEventListener(pName);
            }else{
                PluginCore.removeEventListener(eventIdOrPluginName);
            }
        };
        PluginHelper[pName] = M;
    });
    // 初始化插件
    PluginCore.initAllPlugins(plugins,pluginCorePATH,function(ret){
        cc.log("PluginHelper init ret:",ret)
        PluginHelper.invoke();
    });
};

PluginHelper.destroy = function () {
    PluginCore.dispose();
};

// PluginHelper和NativeManager桥梁
let callfuncs = [];
PluginHelper.registerInitedCallback = function( callback ){
    callfuncs.push(callback);
}
// 由native层调用
PluginHelper.invoke = function(  ){
    callfuncs.forEach(function( cb ){
        cb( PluginHelper )
    })
    callfuncs = [];
}

module.exports = PluginHelper;