//
//  OCExport.m
//  SlotsRoyale2017
//
//  Created by jfxu on 17/01/2017.
//
//
#import "OCExport.h"
#import <CoreTelephony/CTCarrier.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import "Reachability.h"
#import "OpenUDID.h"
#import <AudioToolbox/AudioToolbox.h>

#import "sys/utsname.h"
@implementation OCExport

/**
 * 获得设备的标识符
 */
+ (NSString *)getDeviceId {
    NSString *openUDID = [OpenUDID value];

    return openUDID;
}

/**
 * 振动
 */
+ (void)vibrate {
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
}

/**
 * 获得 imsi 号
 */
+ (NSString *)getIMSI {
    CTTelephonyNetworkInfo *info = [[CTTelephonyNetworkInfo alloc] init];

    CTCarrier *carrier = [info subscriberCellularProvider];

    NSString *mcc = [carrier mobileCountryCode];
    NSString *mnc = [carrier mobileNetworkCode];
    NSString *imsi;
    
    if (mcc == nil || mnc == nil) {
        imsi = @"mac_imsi";
    } else {
        imsi = [NSString stringWithFormat:@"%@%@", mcc, mnc];
    }
    [info release];
    return imsi;
}
+ (NSString *)getIMEI {

    return [OCExport getIMSI];
}
+ (NSString *)getModel {
    // 需要#import "sys/utsname.h"
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString * deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    //iPhone
    if ([deviceString isEqualToString:@"iPhone1,1"])    return @"iPhone 1G";
    if ([deviceString isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    if ([deviceString isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    if ([deviceString isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    if ([deviceString isEqualToString:@"iPhone3,2"])    return @"Verizon iPhone 4";
    if ([deviceString isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    if ([deviceString isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    if ([deviceString isEqualToString:@"iPhone5,2"])    return @"iPhone 5";
    if ([deviceString isEqualToString:@"iPhone5,3"])    return @"iPhone 5C";
    if ([deviceString isEqualToString:@"iPhone5,4"])    return @"iPhone 5C";
    if ([deviceString isEqualToString:@"iPhone6,1"])    return @"iPhone 5S";
    if ([deviceString isEqualToString:@"iPhone6,2"])    return @"iPhone 5S";
    if ([deviceString isEqualToString:@"iPhone7,1"])    return @"iPhone 6 Plus";
    if ([deviceString isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    if ([deviceString isEqualToString:@"iPhone8,1"])    return @"iPhone 6s";
    if ([deviceString isEqualToString:@"iPhone8,2"])    return @"iPhone 6s Plus";
    
    return deviceString;
}

/**
 * 获得 系统版本号
 */
+ (float)getOSVer {
    return [[[UIDevice currentDevice] systemVersion] floatValue];
}

/**
 * 获得游戏版本
 */
+ (NSString *)getGameVer {
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}

/**
 * 获得包名
 */
+ (NSString *)getPackageName {
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
}

/**
 * 获得网络类型
 * return 1-wifi 2-net/wap 3-断网
 */
+ (int)getNetType {
    Reachability *reachability = [Reachability reachabilityWithHostName:@"www.apple.com"];
    NetworkStatus internetStatus = [reachability currentReachabilityStatus];
    int net;
    switch (internetStatus) {
        case ReachableViaWiFi:
            net = 1;
            break;
        case ReachableViaWWAN:
            net = 2;
            break;
        default:
            net = -1;
            break;
    }

    return net;
}

/**
 * 获得mac地址，ios 现在已经拿不到了，为了和android统一，返回一个默认的
 */
+ (NSString *)getMac {
    return @"ios_no_mac";
}

/**
 * 获得内嵌数据，ios不存在多渠道的情况，返回默认的就行了
 */
+ (NSString *)getMetaByKey:(NSString *)key {

    if ([key isEqualToString:@"channel"]) {
        return @"AppStore";
    }

    return nil;
}

/**
 * 申请权限，目前只有一个通知需要申请
 */
+ (void)requestAllPermission {
    float sysVersion = [[UIDevice currentDevice] systemVersion].floatValue;
    if (sysVersion >= 8.0) {
        UIUserNotificationType type = UIUserNotificationTypeBadge | UIUserNotificationTypeAlert | UIUserNotificationTypeSound;
        UIUserNotificationSettings *setting = [UIUserNotificationSettings settingsForTypes:type categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:setting];
    }
}

- (void)dealloc {
    [super dealloc];
}

@end
