//
//  PluginBase.m
//  Game
//
//  Created by howe on 2017/9/4.
//
//

#import "PluginBase.h"
#import "PluginCore.h"

@implementation PluginBase


-(void)initPlugin:(NSDictionary*)params{
    
}

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback{
    
}

-(void)$callEventToJS:(NSString*)type andParams:(NSString*)params
{
    [PluginCore $callEventToJS:self.pluginName andType:type andParams:params];
}
-(void)$callBackToJSOnce:(int)callId andParams:(NSString*)params{
    [PluginCore $callBackToJSOnce:callId andParams:params];
}

-(BOOL)handleOpenURL:(NSURL*)url{
    return NO;
}
-(BOOL)openURL:(NSURL*)url{
    return NO;
}
-(BOOL)continueUserActivity:(nonnull NSUserActivity *)userActivity{
    return NO;
}
@end
