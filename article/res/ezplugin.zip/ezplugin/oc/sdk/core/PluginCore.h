//
//  PluginCore.h
//  Game
//
//  Created by howe on 2017/9/4.
//
//

#import <Foundation/Foundation.h>

@interface PluginCore : NSObject
{
}
/**** 定义工具方法  begin ****/

+(id)parseJSON:(NSString *)jsonString;

/*
 - Top level object is an NSArray or NSDictionary
 - All objects are NSString, NSNumber, NSArray, NSDictionary, or NSNull
 - All dictionary keys are NSStrings
 - NSNumbers are not NaN or infinity
 */
+(NSString*)stringify:(id)arrayOrDict;

/**
  弹窗
 **/
+(void)alert:(NSString*)title andMsg:(NSString*)msg;

/**** 定义工具方法  end ****/

+(void)initAllPlugins:(NSString*)params;

+(void)initPlugin:(NSString*)pluginName andPluginData:(NSString*)params;

+(void)excutePluginAction:(NSString*)pluginName andAction:(NSString*)act andParams:(NSString*)params andCallBack:(NSNumber*)callback;

/** 回调js**/
+(void)$callEventToJS:(NSString*)pluginName andType:(NSString*)type andParams:(NSString*)params;

+(void)$callBackToJSOnce:(int)callId andParams:(NSString*)params;


+(BOOL)handleOpenURL:(NSURL*)url;

+(BOOL)openURL:(NSURL*)url;

+(BOOL)continueUserActivity:(nonnull NSUserActivity *)userActivity;

@end
