//
//  PluginBase.h
//  Game
//
//  Created by howe on 2017/9/4.
//
//

#import <Foundation/Foundation.h>

@interface PluginBase : NSObject
{
}
//插件名
@property (nonatomic,copy ) NSString * pluginName;

-(void)initPlugin:(NSDictionary*)params;

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback;

-(void)$callEventToJS:(NSString*)type andParams:(NSString*)params;

-(void)$callBackToJSOnce:(int)callId andParams:(NSString*)params;

-(BOOL)handleOpenURL:(NSURL*)url;

-(BOOL)openURL:(NSURL*)url;

-(BOOL)continueUserActivity:(nonnull NSUserActivity *)userActivity;

@end
