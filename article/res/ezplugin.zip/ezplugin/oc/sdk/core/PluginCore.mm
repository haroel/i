//
//  PluginCore.m
//  Game
//
//  Created by howe on 2017/9/4.
//
//

#import "PluginCore.h"
#import "PluginBase.h"

#include "ScriptingCore.h"

NSMutableDictionary *_pluginHash = nil;

@implementation PluginCore


+(NSString*)stringify:(id)arrayOrDict{
    if ([NSJSONSerialization isValidJSONObject:arrayOrDict]) {
        NSData *data = [NSJSONSerialization dataWithJSONObject:arrayOrDict options:NSJSONWritingPrettyPrinted error:nil];
        NSString *json = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        return json;
    }
    return @"{}";
}

+(id)parseJSON:(NSString *)jsonString
{
    NSData *jsonData= [jsonString dataUsingEncoding:NSASCIIStringEncoding];
    NSError *error = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData
                                                    options:NSJSONReadingAllowFragments
                                                      error:&error];
    if (jsonObject != nil && error == nil) {
        return jsonObject;
    } else {
        NSLog(@"[PluginCore] Error: json解析错误：%@",error);
        return nil;
    }
}

+(void)alert:(NSString*)title andMsg:(NSString*)msg
{
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *closeAct = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alertController addAction:closeAct];
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    [window.rootViewController presentViewController:alertController animated:YES completion:^{
    }];
}

+(void)initAllPlugins:(NSString *)jsonString andCallback:(NSNumber*)cb
{
    if (_pluginHash == nil){
        _pluginHash = [[NSMutableDictionary alloc] init];
    }else{
        [_pluginHash removeAllObjects];
    }
    NSArray *arr = [PluginCore parseJSON:jsonString];
    for (int i=0;i<arr.count;i++){
        id pluginObj = [arr objectAtIndex:i];
        NSString *pluginName = [pluginObj objectForKey:@"pluginName"];
        PluginBase *plugin = [_pluginHash objectForKey:pluginName];
        if (plugin == nil){
            plugin = [PluginCore __createPlugin:pluginName];
            [_pluginHash setObject:plugin forKey:pluginName];
        }
        id dict = [pluginObj objectForKey:@"params"];
        [plugin initPlugin:dict];
    }
    NSLog(@"[PluginCore]->initAllPlugins finish!");
    int callback = [cb intValue];
    [PluginCore $callBackToJSOnce:callback andParams:@""];
}

+(void)initPlugin:(NSString*)pluginName andPluginData:(NSString*)params{
    PluginBase *plugin = [_pluginHash objectForKey:pluginName];
    if ( plugin == nil ){
        plugin = [PluginCore __createPlugin:pluginName];
        [_pluginHash setObject:plugin forKey:pluginName];
    }
    id dict = [PluginCore parseJSON:params];
    if (dict != nil){
        [plugin initPlugin:dict];
    }
}

+(PluginBase*)__createPlugin:(NSString*)pluginName{
    Class viewClass = NSClassFromString( pluginName );
    if (viewClass != nil){
        PluginBase* plugin = [[viewClass alloc] init];
        [plugin setPluginName:pluginName];
        return plugin;
    }else{
        NSLog(@"[PluginCore] ->__createPlugin Error: %@ class not found!",pluginName);
    }
    return nil;
}

+(void)excutePluginAction:(NSString *)pluginName andAction:(NSString *)act andParams:(NSString *)params andCallBack:(NSNumber*)cb
{
    int callback = [cb intValue];
    if (_pluginHash == nil){
        NSLog(@"[PluginCore] Error: you need init plugincore first! %@",pluginName);
        [PluginCore $callBackToJSOnce:callback andParams:@""];
        return;
    }
    PluginBase* _plugin = [_pluginHash objectForKey:pluginName];
    if (_plugin != nil){
        [_plugin excutePluginAction:act andParams:params andCallback:callback];
    }else{
        NSLog(@"[PluginCore] Error: %@ plugin not found!",pluginName);
        [PluginCore $callBackToJSOnce:callback andParams:@"Error:Plugin not found"];
    }
}

+(BOOL)handleOpenURL:(NSURL*)url
{
    for (id key in _pluginHash) {
        id obj = [_pluginHash objectForKey:key];
        if ( [obj handleOpenURL:url]){
            return YES;
        }
    }
    return FALSE;
}
+(BOOL)openURL:(NSURL*)url
{
    for (id key in _pluginHash) {
        id obj = [_pluginHash objectForKey:key];
        if ( [obj openURL:url]){
            return YES;
        }
    }
    return NO;
}

+ (BOOL)continueUserActivity:(nonnull NSUserActivity *)userActivity{
    for (id key in _pluginHash) {
        id obj = [_pluginHash objectForKey:key];
        if ( [obj continueUserActivity:userActivity]){
            return YES;
        }
    }
    return NO;
}


+(void)$callBackToJSOnce:(int)callId andParams:(NSString*)params{
    
    NSString *str = [NSString stringWithFormat:@"require('PluginCore').nativeCallbackHandlerOnce('%d','%@');",callId,params];
    ScriptingCore * sc = ScriptingCore::getInstance();
    sc->evalString( [str UTF8String]);
}

+(void)$callEventToJS:(NSString*)pluginName andType:(NSString*)type andParams:(NSString*)params{
    NSString *str = [NSString stringWithFormat:@"require('PluginCore').nativeCallbackHandler('%@','%@','%@');",pluginName,type,params];
    ScriptingCore * sc = ScriptingCore::getInstance();
    sc->evalString( [str UTF8String]);
}

@end
