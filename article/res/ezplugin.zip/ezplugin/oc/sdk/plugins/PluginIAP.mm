//
//  PluginIAP.m
//  Game
//
//  Created by howe on 2017/9/13.
//
//

#import "PluginIAP.h"
#include "IAPApi.h"
#include "IAPMsgHandler.h"

@implementation PluginIAP

-(void)initPlugin:(NSDictionary*)params{
    
    auto func = [&](int code,const std::string &msg){
        
        [self $callEventToJS:@"hh" andParams:@""];
        
    };
    // 注册IAP信息回调
    IAPMsgHandler::getInstance()->registerCallback( std::bind(func, std::placeholders::_1,std::placeholders::_2) );
}

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback{

    
}

@end
