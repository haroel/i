//
//  PluginWechat.h
//  Game
//
//  Created by howe on 2017/9/4.
// 微信插件
//

#import "PluginBase.h"
#import <WXApi.h>

@interface PluginWechat : PluginBase <WXApiDelegate>
-(void)initPlugin:(NSDictionary*)params;

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback;

-(BOOL)handleOpenURL:(NSURL*)url;

-(BOOL)openURL:(NSURL*)url;

@end
