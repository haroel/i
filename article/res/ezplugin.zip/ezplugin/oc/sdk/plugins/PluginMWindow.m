//
//  PluginMWindow.m
//  Game
//
//  Created by howe on 2017/9/11.
//
//

#import "PluginMWindow.h"
#import "PluginCore.h"

@implementation PluginMWindow


-(void)initPlugin:(NSDictionary*)params{
    
    schemeTag = params[@"scheme"];
    //
    NSString *mlinkKey = params[@"mlinkKey"];
    [MWApi registerApp:params[@"appKey"]];
    
    _mlinkParams = @"{}";
    
    [MWApi registerMLinkDefaultHandler:^(NSURL * _Nonnull url, NSDictionary * _Nullable params)
     {
        NSLog(@"*********** registerMLinkDefaultHandler call ,%@",params);
        _mlinkParams = [PluginCore stringify:params];
    }];
    [MWApi registerMLinkHandlerWithKey:mlinkKey handler:^(NSURL * _Nonnull url, NSDictionary * _Nullable params)
     {
        NSLog(@"*********** Mlink触发！获得Mlink参数: %@",params);
        _mlinkParams = [PluginCore stringify:params];
        // 调试弹窗
//        [PluginCore alert:@"进入房间" andMsg:[NSString stringWithFormat:@"房号%@",params[@"id"]]];
        [self $callEventToJS:@"linkData" andParams:_mlinkParams];
    }];
}

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback{
    if ([type isEqualToString:@"getLinkData"]){
        [self $callBackToJSOnce:callback andParams:_mlinkParams];
    }
}

-(BOOL)continueUserActivity:(nonnull NSUserActivity *)userActivity{
    //如果使用了Universal link ，此方法必写
    return [MWApi continueUserActivity:userActivity];
}

-(BOOL)openURL:(NSURL*)url{
    NSString * urlStr = [url absoluteString];
    NSRange range = [urlStr rangeOfString:schemeTag];
    if (range.location != NSNotFound){
        [MWApi routeMLink:url];
        return YES;
    }
    return NO;
}
@end
