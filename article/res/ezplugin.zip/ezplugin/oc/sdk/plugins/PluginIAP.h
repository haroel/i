//
//  PluginIAP.h
//  Game
//
//  Created by howe on 2017/9/13.
//
//

#import "PluginBase.h"

@interface PluginIAP : PluginBase

-(void)initPlugin:(NSDictionary*)params;

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback;


@end
