//
//  PluginMWindow.h
//  Game
//
//  Created by howe on 2017/9/11.
//
//

#import "PluginBase.h"
#import <MWApi.h>
@interface PluginMWindow : PluginBase
{
    NSString * _mlinkParams;
    NSString *schemeTag;
}

-(void)initPlugin:(NSDictionary*)params;

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback;

-(BOOL)openURL:(NSURL*)url;

//如果使用了Universal link ，此方法必写
-(BOOL)continueUserActivity:(nonnull NSUserActivity *)userActivity;

@end
