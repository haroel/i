//
//  PluginBugly.m
//  Game
//
//  Created by howe on 2017/9/4.
//
//

#import "PluginBugly.h"
#import <Bugly/Bugly.h>
@implementation PluginBugly

-(void)initPlugin:(NSDictionary*)params{
    [Bugly startWithAppId:[params objectForKey:@"appId"]];
    [Bugly setUserValue:[params objectForKey:@"debug"] forKey:@"BuglyDebugEnable"];
}

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback{
    if ([type isEqualToString:@"setAppChannel"]){
        [Bugly setUserValue:params forKey:@"BuglyAppChannelString"];
    }else if ( [type isEqualToString:@"setAppVersion"]){
        [Bugly setUserValue:params forKey:@"BuglyAppVersionString"];
    }else if ( [type isEqualToString:@"setAppPackageName"]){
        [Bugly setUserValue:params forKey:@"BuglyAppPackageString"];
    }else if ( [type isEqualToString:@"setUserSceneTag"]){
        [Bugly setTag:[params intValue]];
    }else if ( [type isEqualToString:@"setUserId"]){
        [Bugly setUserIdentifier:params];
    }else if ( [type isEqualToString:@"reportJsCrash"]){
        [Bugly reportException:[NSException exceptionWithName:@"buglyException" reason:params userInfo:nil]];
    }else if ( [type isEqualToString:@"init"]){
        
    }
}


@end
