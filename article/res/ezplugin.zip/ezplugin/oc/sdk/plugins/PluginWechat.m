//
//  PluginWechat.m
//  Game
//
//  Created by howe on 2017/9/4.
//
//

#import "PluginWechat.h"
#import "PluginCore.h"

#import <WXApiObject.h>

@implementation PluginWechat



-(void)initPlugin:(NSDictionary*)params{
    
    NSString *appId = [params objectForKey:@"appId"];
    [WXApi registerApp:appId];
    NSLog(@"wechat 初始化");
}

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback{

    if ([type isEqualToString:@"isInstalled"])
    {
        NSString *ret =[WXApi isWXAppInstalled]?@"1":@"0";
        [self $callBackToJSOnce:callback andParams:ret];
        
    }else if ( [type isEqualToString:@"login"]){
        //构造SendAuthReq结构体
        SendAuthReq* req =[[[SendAuthReq alloc ] init ] autorelease ];
        req.scope = @"snsapi_userinfo" ;
        req.state = params ;
        //第三方向微信终端发送一个SendAuthReq消息结构
        [WXApi sendReq:req];
        
    }else if ( [type isEqualToString:@"share"]){
        if (![WXApi isWXAppInstalled]){
            NSLog(@"PluginWechat 微信未安装！");
            NSString *uu = [WXApi getWXAppInstallUrl];
            [self $callEventToJS:@"wechat_not_installed" andParams:uu];
            return;
        }
        // 微信分享
        NSDictionary *dict = [PluginCore parseJSON:params];
        if (!dict){
            NSLog(@"PluginWechat 分享参数错误%@",params);
            [self $callBackToJSOnce:callback andParams:@""];
            return;
        }
        BOOL bText = NO;
        WXMediaMessage *msg = [WXMediaMessage message];
        NSString *share_type = dict[@"type"];
        if ([share_type isEqualToString:@"link"])
        {
            bText = YES;
            WXWebpageObject *exObj =[WXWebpageObject object];
            exObj.webpageUrl = dict[@"link"];;
            msg.mediaObject = exObj;
        }else if ([share_type isEqualToString:@"text"])
        {
            WXTextObject *exObj = [WXTextObject object];
            exObj.contentText = dict[@"body"];
            msg.mediaObject = exObj;
        }
        if ([dict objectForKey:@"description"]){
            msg.description = dict[@"description"];
        }
        int scene = WXSceneSession;
        if ([dict objectForKey:@"scene"]){
            scene =dict[@"scene"];
        }
        NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
        msg.title = [infoDictionary objectForKey:@"CFBundleDisplayName"];
        NSString *icon = [[infoDictionary valueForKeyPath:@"CFBundleIcons.CFBundlePrimaryIcon.CFBundleIconFiles"] objectAtIndex:1];
        [msg setThumbImage:[UIImage imageNamed:icon]];
        
        SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
        req.bText = bText;
        req.message = msg;
        req.scene = WXSceneSession;
        [WXApi sendReq:req];
    }
}

-(void)toAppStore{
    if (![WXApi isWXAppInstalled]){
        NSLog(@"微信未安装，跳转至App Store");
        NSURL * url = [NSURL URLWithString:[WXApi getWXAppInstallUrl]];
        if ([[UIApplication sharedApplication] canOpenURL:url]) {
            if ([[UIDevice currentDevice].systemVersion floatValue] >9.9) {
                [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
                    NSLog(@"success = %d",success);
                }];
            }else{
                [[UIApplication sharedApplication] openURL:url];
            }
        }
    }
}
////onReq是微信终端向第三方程序发起请求，要求第三方程序响应。第三方程序响应完后必须调用sendRsp返回。在调用sendRsp返回时，会切回到微信终端程序界面。
-(void) onReq:(BaseReq*)req{
    
}

//BaseResp：所有响应类的基类。
//
//GetMessageFromWXResp：第三方向微信终端返回处理结果类型。
//
//SendMessageToWXResp：微信处理完程序发送的请求后返回的结果类型。
//
//ShowMessageFromWXResp：第三方程序处理完向微信终端发送的处理结果。
////如果第三方程序向微信发送了sendReq的请求，那么onResp会被回调。sendReq请求调用后，会切到微信终端程序界面。
-(void) onResp:(BaseResp*)resp{
    NSLog(@"PluginWechat->onResp: type:%d,errCode: resp.errCode:%d",resp.type,resp.errCode);
    if (resp.type == 0){
        NSLog(@"授权结果 %d",resp.errCode);
        switch (resp.errCode) {
            case WXSuccess:
            {
                if([resp isKindOfClass:[SendMessageToWXResp class]])
                {
                    NSLog(@"分享成功");
                }
                if([resp isKindOfClass:[SendAuthResp class]])
                {
                    SendAuthResp *ret = (SendAuthResp*)resp;
                    [self $callEventToJS:@"wechat_auth_success" andParams:ret.code];
                }
                break;
            }
            default:
                NSLog(@"授权失败 %@",resp.errStr);
                break;
        }
        
    }
}

-(BOOL)handleOpenURL:(NSURL*)url{
    return [self openURL:url];
}

-(BOOL)openURL:(NSURL*)url{
    NSString * urlStr = [url absoluteString];
    NSRange range = [urlStr rangeOfString:@"wechat"];
    if (range.location != NSNotFound){
        return [WXApi handleOpenURL:url delegate:self];
    }
    return NO;
}

@end
