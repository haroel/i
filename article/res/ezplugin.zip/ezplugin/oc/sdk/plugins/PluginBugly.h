//
//  PluginBugly.h
//  Game
//
//  Created by howe on 2017/9/4.
//
//

#import "PluginBase.h"

@interface PluginBugly : PluginBase

-(void)initPlugin:(NSDictionary*)params;

-(void)excutePluginAction:(NSString*)type andParams:(NSString*)params andCallback:(int)callback;

@end
