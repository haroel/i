package com.sdkplugin.core;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import com.bainagame.extensionlib.ActivityLifecycleHandler;

import org.cocos2dx.lib.Cocos2dxJavascriptJavaBridge;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;

import static org.cocos2dx.lib.Cocos2dxHelper.runOnGLThread;

/**
 *
 * Created by hehao on 2017/7/17.
 */

public class PluginCore {

    private static final String TAG = "PluginCore";
    // 包名
    private static final String PACKAGE = "com.sdkplugin.plugins";

    private static HashMap<String,PluginBase> pluginMap = new HashMap<String,PluginBase>();
    private static Activity mContext = null;

    public static void initCore(final Activity context){
        mContext = context;
    }

    public static void onResume(Intent intent){

        for (HashMap.Entry<String, PluginBase> entry : pluginMap.entrySet()) {
            entry.getValue().onResume(intent);
        }
    }
    public static void onPause(Intent intent){
        for (HashMap.Entry<String, PluginBase> entry : pluginMap.entrySet()) {
            entry.getValue().onPause(intent);
        }

    }
    public static void onNewIntent(Intent intent){
        for (HashMap.Entry<String, PluginBase> entry : pluginMap.entrySet()) {
            entry.getValue().onNewIntent(intent);
        }

    }
    public static void onDestroy(){
        for (HashMap.Entry<String, PluginBase> entry : pluginMap.entrySet()) {
            entry.getValue().onDestroy();
        }
    }

    public static PluginBase getPluginByName(String pluginName){
        return pluginMap.get(pluginName);
    }

    public static void initAllPlugins( final String params,final int callback )
    {
        mContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
            try {
                JSONArray jsonArray = new JSONArray(params);
                for(int i = 0; i < jsonArray.length(); i++) {
                    JSONObject oj = jsonArray.getJSONObject(i);
                    String pluginName = oj.getString("pluginName");
                    PluginBase plugin = pluginMap.get(pluginName);
                    if (plugin == null){
                        // 防止重复构建
                        plugin = __createPlugin(pluginName);
                        pluginMap.put(pluginName,plugin);
                    }
                    plugin.initPlugin( mContext , oj.getJSONObject("params") );
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
            Log.d(TAG,"initAllPlugins finish!");
            PluginCore.$callBackToJSOnce(callback,"1");
            }
        });
    }
    public static void initPlugin( final String pluginName,final String pluginParams )
    {
        mContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
            Log.d(TAG," initPlugin "+pluginName);
            try {
                PluginBase plugin = pluginMap.get(pluginName);
                if (plugin == null){
                    plugin = __createPlugin(pluginName);
                    pluginMap.put(pluginName,plugin);
                }

                JSONObject jobj = new JSONObject(pluginParams);
                plugin.initPlugin(mContext,jobj);
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
            }
        });
    }
    private static PluginBase __createPlugin(final String pluginName)
    {
        try {
            Class<?> Cls = Class.forName(PACKAGE +"." + pluginName);
            PluginBase plugin = (PluginBase)(Cls.newInstance());
            return plugin;
        }
        catch (ClassNotFoundException e){
            e.printStackTrace();
        }
        catch (IllegalAccessException e){
            e.printStackTrace();
        }
        catch (InstantiationException e){
            e.printStackTrace();
        }
        Log.e(TAG,"__createPlugin 失败"+pluginName);
        return null;
    }
    /*
    * 执行插件方法
    * pluginName : 插件类名
    * action ： 执行动作类型
    * params ：参数
    * */
    public static void excutePluginAction(final String pluginName,final String action, final String params,final int callback)
    {
        Log.d(TAG," excutePluginAction: " + pluginName + "  action:" +action);
        PluginBase plugin = getPluginByName(pluginName);
        if (plugin != null){
            try{
                plugin.excutePluginAction( action,params,callback);
            }catch (Exception e){
                e.printStackTrace();
                Log.e(TAG,"excutePluginAction Error ：" + pluginName + " ：" + params);
                PluginCore.$callBackToJSOnce(callback,"error, " + pluginName + " excutePluginAction");
            }
        }else{
            Log.e(TAG," Not found ：" + pluginName);
            PluginCore.$callBackToJSOnce(callback,"error, " + pluginName + " Not found!");
        }
    }
    /*
    * 在Android UI主线程中执行插件方法。
    * 相当于异步调用
    * pluginName : 插件类名
    * action ： 执行动作类型
    * params ：参数
    * */
    public static void excutePluginActionInUITheard(final String pluginName,final String action, final String params,final int callback)
    {
        mContext.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                excutePluginAction( pluginName,action,params,callback );
            }
        });
    }

    // 事件机制 Java回调js
    public static void $callEventToJS(final String pluginName,final String event,final String params){
        if (pluginName.isEmpty()){
            return;
        }
        runOnGLThread(new Runnable() {
            @Override
            public void run() {
            String _safeStr = String.format("require('PluginCore').nativeCallbackHandler('%s','%s','%s');",pluginName,event,params);
            Cocos2dxJavascriptJavaBridge.evalString(_safeStr);
            }
        });
    }
    // 回调函数机制，一次有效 Java回调js
    public static void $callBackToJSOnce(final int callbackId,final String params){
        if (callbackId == 0){
            return;
        }
        runOnGLThread(new Runnable() {
            @Override
            public void run() {
            String _safeStr = String.format("require('PluginCore').nativeCallbackHandlerOnce('%d','%s');",callbackId,params);
            Cocos2dxJavascriptJavaBridge.evalString(_safeStr);
            }
        });
    }
}
