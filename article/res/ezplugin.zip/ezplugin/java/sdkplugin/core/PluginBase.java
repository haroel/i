package com.sdkplugin.core;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import org.json.JSONObject;

/**
 * 插件基类
 * 抽象类，禁止实例化，必须继承
 * Created by hehao on 2017/7/18.
 */

public abstract class PluginBase {

    private Context mContext = null;

    public Context getContext(){
        return this.mContext;
    }

    public Application getApplication(){
        return ((Activity)(this.mContext)).getApplication();
    }
    /*
    * 获取类名
    * */
    public String name(){
        return this.getClass().getSimpleName();
    }

    public void initPlugin(Context context, JSONObject jobj){
        this.mContext = context;
        String ClsName = this.getClass().getName();
        Log.d(ClsName,"initPlugin");
    }

    public void excutePluginAction(String type,String params,final int callback){

    }

    public void onResume(Intent intent){

    }
    public void onPause(Intent intent){

    }
    public void onDestroy(){

    }
    public void onNewIntent(Intent intent){

    }
    /*
    * 调用此方法将事件传给JS层
    * */
    final protected void $callEventToJS( String evt , String params){
        String PluginName = this.getClass().getSimpleName();
        PluginCore.$callEventToJS(PluginName,evt,params);
    }
    /*
    * 调用此方法将参数通过callback函数形式传给JS层，只会一次有效。注意与$eventToJS区别！
    * */
    final protected void $callBackToJSOnce(final int callbackId,final String params){
        PluginCore.$callBackToJSOnce(callbackId,params);
    }

}
