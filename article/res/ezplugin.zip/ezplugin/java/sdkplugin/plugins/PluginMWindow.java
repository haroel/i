package com.sdkplugin.plugins;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.widget.Toast;

import com.sdkplugin.core.PluginBase;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Set;

import cn.magicwindow.MLinkAPIFactory;
import cn.magicwindow.MWConfiguration;
import cn.magicwindow.MagicWindowSDK;
import cn.magicwindow.Session;

/**
 * Created by howe on 2017/9/8.
 *
 * 魔窗 链接跳转app
 */
public class PluginMWindow extends PluginBase {

    // 浏览器Uri参数解析
    private String _linkData = "";
    @Override
    public void initPlugin(Context context, JSONObject jobj) {
        super.initPlugin(context, jobj);
        try {
            MWConfiguration config = new MWConfiguration(context);
            config.setLogEnable( jobj.getBoolean("debug") );//打开魔窗Log信息
            MagicWindowSDK.initSDK(config);
            MLinkAPIFactory.createAPI(context).registerWithAnnotation(context);
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        excuteMlink( ((Activity)context).getIntent());
    }

    @Override
    public void excutePluginAction(String type, String params, int callback) {
        super.excutePluginAction(type, params, callback);
        if (type.equals("getLinkData")){
            // 回传给游戏
            if (this._linkData.length() > 0 ){
                $callBackToJSOnce( callback, this._linkData );
            }else{
                $callBackToJSOnce( callback, "");
            }
        }else if (type.equals("deleteLinkData")){
            _linkData = "";
        }
    }

    private void excuteMlink(Intent intent){
        //动态参数获取
        _linkData = "";
        if (intent != null) {
            //动态参数获取
            String _d = intent.getDataString();
            if (_d!= null){
                Uri uri = Uri.parse(_d);
                Set<String> paramSets = uri.getQueryParameterNames();
                if (paramSets.size() > 0){
                    try{
                        JSONObject jobj = new JSONObject();
                        for(String key : paramSets ){
                            jobj.put(key, uri.getQueryParameter(key));
                        }
                        /**
                         * mlink数据: {"mw_dc_order":"","id":"10011","mw_mk":"A04M","mw_tags":"","mw_ck":"短信","mw_tk":"ff2515e4bc7bc7d0139f08e3c93fdbe341a36316","mw_ulp":"JTdCJTIydHlwZSUyMiUzQSUyMiUyMiUyQyUyMmlkJTIyJTNBJTIyJTIyJTdE","mw_slk":"A04O","mw_ios_dc":"","type":"landlord","mw_dc":"","mw_android_dc":""}
                         * **/
                        _linkData = jobj.toString();
                        Log.d("mlink数据",_linkData);
                        // 在游戏的大厅监听该事件
                        $callEventToJS("linkData", _linkData );
                    }catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                }

            }
        }
    }
    @Override
    public void onNewIntent(Intent intent) {
        super.onPause( intent);
        excuteMlink(intent);
    }
    @Override
    public void onResume(Intent intent) {
        super.onResume(intent);
        Session.onResume(getContext());
    }

    @Override
    public void onPause(Intent intent) {
        super.onPause( intent);
        Session.onPause(getContext());
    }
}
