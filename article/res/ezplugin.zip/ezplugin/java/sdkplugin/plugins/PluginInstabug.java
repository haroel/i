package com.sdkplugin.plugins;

import android.content.Context;
//import com.instabug.library.Instabug;
//import com.instabug.library.invocation.InstabugInvocationEvent;

import com.sdkplugin.core.PluginBase;

import org.json.JSONObject;


/**
 * 第三方问题反馈系统(dashboard.instabug.com)
 * Created by baina on 2017/7/14.
 */

public class PluginInstabug extends PluginBase {

    public PluginInstabug(Context context){
        // Instabug 初始化有个bug，必须在onCreate方法的栈调用链里初始化，否则会报错并崩溃 WTF!
//        new Instabug.Builder( ((Activity)(context)).getApplication(), "5aa58494b37e8868442c609a6a3c7d37")
//                .setInvocationEvent(InstabugInvocationEvent.NONE)
//                .build();
    }
    @Override
    public void initPlugin(Context context, JSONObject params) {
//        super.initPlugin(context,params);
//        Instabug.setEmailFieldRequired(false);
//        Instabug.setWillSkipScreenshotAnnotation(true);
//        Instabug.setPromptOptionsEnabled(false,false,true);
//        // 只允许截图，查看相册，关闭语音和视频录制
//        Instabug.setAttachmentTypesEnabled(true,true,true,false,false);
//        try {
////            String token = params.getString("token");
//            String fcmToken = params.getString("fcmToken");
//            // 设置instabug fcm推送token
//            Instabug.setPushNotificationRegistrationToken(fcmToken);
//        }catch (JSONException e){
//            e.printStackTrace();
//        }
    }

    @Override
    public void excutePluginAction(String type,String params,final int callback){
//        if (type.equals("feedback")){
//            try{
//                Instabug.setUserAttribute("userId", params);
//                Instabug.invoke();
//                $callBackToJSOnce(callback,"open feedback!");
//            }catch (Exception e){
//                e.printStackTrace();
//                $callBackToJSOnce(callback,"Error, 打开Instabug出错!");
//            }
//        }
    }
}
