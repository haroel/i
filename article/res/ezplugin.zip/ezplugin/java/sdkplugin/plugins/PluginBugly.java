package com.sdkplugin.plugins;

import android.content.Context;
import android.util.Log;

import com.tencent.bugly.crashreport.CrashReport;

import com.sdkplugin.core.PluginBase;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 腾讯Bugly https://bugly.qq.com
 * Created by gdong on 2017/8/2.
 */
public class PluginBugly extends PluginBase {
    private String mAppId =  "7dc149a264";
    private boolean mDebug = true;
    private Context mApplicationContext;

    public void initPlugin(Context context, JSONObject params) {
        super.initPlugin(context,params);
        try {
            mAppId = params.getString("appId");
            mDebug = params.getBoolean("debug");
            mApplicationContext = context.getApplicationContext();
        }
        catch (JSONException e){
            e.printStackTrace();
        }
    }

    @Override
    public void excutePluginAction(String type,String params, final int callback){
        if (type.equals("setAppChannel")){
            Log.d("BuglyPlugin","设置渠道名为" + params);
            setAppChannel(params);
        }
        else if(type.equals("setAppVersion")){
            Log.d("BuglyPlugin","设置版本号为" + params);
            setAppVersion(params);
        }
        else if(type.equals("setAppPackageName")){
            Log.d("BuglyPlugin","设置包名为" + params);
            setAppPackageName(params);
        }
        else if(type.equals("setUserSceneTag")){
            setUserSceneTag(Integer.parseInt(params));
        }
        else if(type.equals("setUserId")){
            Log.d("BuglyPlugin","设置用户编号为" + params);
            setUserId(params);
        }
        else if(type.equals("reportJsCrash")){
            reportJsCrash(params);
        }
        else if (type.equals("init")){
            CrashReport.initCrashReport(mApplicationContext, mAppId, mDebug);
            Log.d("BuglyPlugin","初始化完成");
        }

        $callBackToJSOnce(callback,"success");
    }

    /**
     * 设置渠道名
     * @param channel 渠道名
     */
    private void setAppChannel(String channel) {
        CrashReport.setAppChannel(mApplicationContext, channel);
    }

    /**
     * 设置应用版本名
     * @param version 版本名
     */
    private void setAppVersion(String version) {
        CrashReport.setAppVersion(mApplicationContext, version);
    }

    /**
     * 设置应用包名
     * @param packageName 应用包名
     */
    private void setAppPackageName(String packageName) {
        CrashReport.setAppPackage(mApplicationContext, packageName);
    }

    /**
     * 设置场景标签，当发生 crash 时，上报信息中会将最近一次添加的标签附加进去。该标签需要在
     * bugly 的标签管理页面中创建。
     *
     * @param tag
     */
    private void setUserSceneTag(int tag) {
        CrashReport.setUserSceneTag(mApplicationContext, tag);
    }

    /**
     * 设置自定义数据，发生 crash 时，上报信息中会附加该 key-value 对。最多附加 9 对自定义 key-value（暂没使用）
     *
     * @param key
     * @param value
     */
    private void setUserData(String key, String value) {
        CrashReport.putUserData(mApplicationContext, key, value);
    }

    /**
     * 设置用户 ID，上报时会附加该信息
     *
     * @param id
     */
    private void setUserId(String id) {
        CrashReport.setUserId(mApplicationContext, id);
    }

    /**
     * 上报 js 的异常信息。这里属于主动上报，程序并不会因为调用该接口而中断。
     * @param err js 报错堆栈信息
     */
    private void reportJsCrash(final String err){
        reportThrowable(new Exception(err));
    }

    /**
     * 主动上报异常，在 catch 中上报捕获的异常
     *
     * @param thr
     */
    private void reportThrowable(Throwable thr) {
        CrashReport.postCatchedException(thr);
    }

}
