package com.sdkplugin.plugins;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.balingqipai.com.R;
import com.sdkplugin.Util;
import com.sdkplugin.core.PluginBase;

import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXTextObject;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by howe on 2017/9/4.
 */
public class PluginWechat extends PluginBase {

    private String appId = "";
//    private String appSecret = "";

    private static IWXAPI api = null;
    private static SendAuth.Resp authResp = null;

    public static void saveResp(SendAuth.Resp resp){
        authResp = resp;
    }
    public static IWXAPI getWXAPI(){
        return api;
    }

    @Override
    public void initPlugin(Context context, JSONObject jobj) {
        super.initPlugin(context, jobj);
        try {
            appId = jobj.getString("appId");
//            appSecret = jobj.getString("appSecret");
            api = WXAPIFactory.createWXAPI(context,appId,true);
            api.registerApp(appId);
        }
        catch (JSONException e){
            e.printStackTrace();
        }
    }
    private String buildTransaction(String paramString) {
        String str;
        if (paramString != null)
            str = paramString + System.currentTimeMillis();
        else
            str = String.valueOf(System.currentTimeMillis());
        return str;
    }

    @Override
    public void excutePluginAction(String type, String params, final int callback) {
        super.excutePluginAction(type, params, callback);

        if (type.equals("isInstalled")){
            $callBackToJSOnce(callback, api.isWXAppInstalled()?"1":"0");
        } else if (type.equals("login")){
            if (!api.isWXAppInstalled())
            {
                $callEventToJS("wechat_not_installed","" );
                return;
            }
            wechatAuth(params);
        }else if (type.equals("share")){
            // 微信分享
            if (!api.isWXAppInstalled()) {
                Log.d("PluginWechat","微信未安装！");
                $callEventToJS("wechat_not_installed","" );
                return;
            }
            try {
                JSONObject dict = new JSONObject(params);
                WXMediaMessage msg = new WXMediaMessage();
                String share_type = dict.getString("type");
                if ( share_type.equals("link") )
                {
                    WXWebpageObject exObj = new WXWebpageObject();
                    exObj.webpageUrl = dict.getString("link");
                    msg.mediaObject = exObj;

                }else if (share_type.equals("text"))
                {
                    WXTextObject exObj = new WXTextObject();
                    exObj.text = dict.getString("body");
                    msg.mediaObject = exObj;
                }
                if (dict.has("description")){
                    msg.description = dict.getString("description");
                }
                int scene = SendMessageToWX.Req.WXSceneSession;
                if (dict.has("scene") ){
                    scene = dict.getInt("scene");
                }
                msg.title= this.getContext().getResources().getString(R.string.app_name);
                Bitmap thumb = BitmapFactory.decodeResource(this.getContext().getResources(),R.mipmap.ic_launcher );
                msg.setThumbImage(thumb);

                SendMessageToWX.Req req = new SendMessageToWX.Req();
                req.transaction = buildTransaction("share_type");
                req.message = msg;
                req.scene = scene;
                api.sendReq(req);

                $callBackToJSOnce(callback, "share over");
            }catch (JSONException e){
                e.printStackTrace();
                $callBackToJSOnce(callback, "");
            }
        }
    }
    private void wechatAuth(String params ){
        // send oauth request
        final SendAuth.Req req = new SendAuth.Req();
        req.scope = "snsapi_userinfo";
        req.state = params;
        api.sendReq(req);
    }

    @Override
    public void onResume(Intent intent) {
        super.onResume(intent);
        if (authResp != null){
            String code = authResp.code;
            $callEventToJS("wechat_auth_success", code);
            authResp = null;
        }
    }
}
